<?php
header('location:index.php?s=admin/index/index');








