<extend file='resource/view/master'/>
<block name="content">
    <table class="table table-hover">
        <tbody>
        <tr>
            <th class="active" colspan="10">温馨提示</th>
        </tr>
        <tr>
            <td colspan="10">HDBLOG_EDU是国内唯一真正的百分百免费开源产品，可以用在任何网站（包括商业网站），您不用担心任何版权问题。</td>
        </tr>
        <tr>
            <th class="active" colspan="10">系统信息</th>
        </tr>
        <tr>
            <td>核心框架</td>
            <td colspan="5">Hdphp2.0</td>
        </tr>
        <tr>
            <td>版本号</td>
            <td colspan="5">1.0.0</td>
        </tr>
        <tr>
            <td>运行环境</td>
            <td colspan="5"><?php echo PHP_OS;?></td>
        </tr>
        <tr>
            <td>开发者</td>
            <td colspan="5">后盾网</td>
        </tr>
        </tbody>
    </table>
</block>



